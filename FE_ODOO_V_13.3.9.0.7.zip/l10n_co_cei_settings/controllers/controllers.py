# -*- coding: utf-8 -*-
from odoo import http

